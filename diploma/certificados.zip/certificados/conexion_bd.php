<?php
// Configuración de la base de datos

$host = "68.178.246.37";
$user = "Desarrollo";
$pass = "y9B>^y=>FT+G`C@,";
$database = "Eduessence";

// Conexión a la base de datos
$conexion = mysqli_connect($host, $user, $pass, $database);
?>